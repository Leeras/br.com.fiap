package br.com.fiap;

public class Caminhao extends Veiculo {
    public Caminhao(String cor, double peso, String marca, int anoFabricacao) {
        super(cor, peso, marca, anoFabricacao);
    }
}