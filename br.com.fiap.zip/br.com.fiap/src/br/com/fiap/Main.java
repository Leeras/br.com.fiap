package br.com.fiap;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Carro carro = new Carro("Preto", 1000.0, "Fiat", 2020);
        Caminhao caminhao = new Caminhao("Branco", 5000.0, "Volvo", 2015);

        Scanner sc = new Scanner(System.in);
        int opcao = 0;

        do {
            System.out.println("Selecione uma opção:");
            System.out.println("1. Ligar veículo");
            System.out.println("2. Desligar veículo");
            System.out.println("3. Acelerar");
            System.out.println("4. Frear");
        	}
    
    }
}