package br.com.fiap;

public class Carro extends Veiculo {
    public Carro(String cor, double peso, String marca, int anoFabricacao) {
        super(cor, peso, marca, anoFabricacao);
    }
}
