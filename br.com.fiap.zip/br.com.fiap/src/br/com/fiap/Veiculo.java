package br.com.fiap;

	public class Veiculo {
	    private String cor;
	    private double peso;
	    private String marca;
	    private int anoFabricacao;
	    private boolean ligado;
	    private double velocidade;

	    // Construtor
	    public Veiculo(String cor, double peso, String marca, int anoFabricacao) {
	        this.cor = cor;
	        this.peso = peso;
	        this.marca = marca;
	        this.anoFabricacao = anoFabricacao;
	        this.ligado = false;
	        this.velocidade = 0;
	    }

	    // Métodos
	    public void ligar() {
	        if (!this.ligado) {
	            this.ligado = true;
	            System.out.println("Veículo ligado.");
	        } else {
	            System.out.println("O veículo já está ligado.");
	        }
	    }

	    public void desligar() {
	        if (this.ligado && this.velocidade == 0) {
	            this.ligado = false;
	            System.out.println("Veículo desligado.");
	        } else if (this.velocidade > 0) {
	            System.out.println("Não é possível desligar o veículo enquanto estiver em movimento.");
	        } else {
	            System.out.println("O veículo já está desligado.");
	        }
	    }

	    public void acelerar(double velocidade) {
	        if (this.ligado) {
	            this.velocidade += velocidade;
	            System.out.println("Acelerando. Velocidade atual: " + this.velocidade + " km/h");
	        } else {
	            System.out.println("O veículo precisa estar ligado para acelerar.");
	        }
	    }

	    public void frear() {
	        if (this.velocidade > 0) {
	            this.velocidade = 0;
	            System.out.println("Freando. Velocidade atual: " + this.velocidade + " km/h");
	        } else {
	            System.out.println("O veículo já está parado.");
	        }
	    }
	
}
